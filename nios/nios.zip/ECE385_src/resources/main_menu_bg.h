#ifndef RESOURCES_MAIN_MENU_BG_H_
#define RESOURCES_MAIN_MENU_BG_H_

#include <stdint.h>
#include "resource.h"

extern uint16_t main_menu_bg[640 * 480];

#endif /* RESOURCES_MAIN_MENU_BG_H_ */
